package com.exception;

public class InvalidAllocationException extends Exception {
			
	public InvalidAllocationException(String message)
	{
		super(message);
	}
	
}
