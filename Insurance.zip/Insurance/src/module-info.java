/**
 * 
 */
/**
 * 
 */
module Insurance {
	requires java.sql;
}